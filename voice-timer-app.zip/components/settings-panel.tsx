"use client"

import { Volume2, Languages, Bell, Music } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useSettings, type AnnouncementMode } from "@/components/settings-provider"
import { useSpeech } from "@/hooks/use-speech"
import { LANGUAGES, t, type LangCode } from "@/lib/i18n"

const INTERVALS: { value: number; key: "every10s" | "every30s" | "everyMinute" | "every5min" | "onlyAtEnd" }[] = [
  { value: 10, key: "every10s" },
  { value: 30, key: "every30s" },
  { value: 60, key: "everyMinute" },
  { value: 300, key: "every5min" },
  { value: 0, key: "onlyAtEnd" },
]

function SectionHeader({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 text-sm font-semibold">
      <span className="text-primary">{icon}</span>
      {children}
    </div>
  )
}

export function SettingsPanel() {
  const { settings, update } = useSettings()
  const { speak, unlock } = useSpeech()
  const lang = settings.language

  const handleTestVoice = () => {
    unlock()
    speak(t(lang, "testPhrase"), lang)
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Voice toggle */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between gap-4">
          <Label htmlFor="voice-switch" className="flex items-center gap-2 text-sm font-medium">
            <Volume2 className="size-4 text-primary" aria-hidden="true" />
            {t(lang, "announceVoice")}
          </Label>
          <Switch
            id="voice-switch"
            checked={settings.voiceEnabled}
            onCheckedChange={(v) => update("voiceEnabled", v)}
          />
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleTestVoice}
          disabled={!settings.voiceEnabled}
          className="w-full"
        >
          <Volume2 className="size-4" aria-hidden="true" />
          {t(lang, "testVoice")}
        </Button>
      </div>

      <div className="h-px bg-border" />

      {/* Language */}
      <div className="flex flex-col gap-3">
        <SectionHeader icon={<Languages className="size-4" aria-hidden="true" />}>
          {t(lang, "language")}
        </SectionHeader>
        <Select value={settings.language} onValueChange={(v) => update("language", v as LangCode)}>
          <SelectTrigger aria-label={t(lang, "language")}>
            <SelectValue>
              {LANGUAGES.find((l) => l.code === settings.language)?.label}
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            {LANGUAGES.map((l) => (
              <SelectItem key={l.code} value={l.code}>
                {l.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="h-px bg-border" />

      {/* Announcement type */}
      <div className="flex flex-col gap-3">
        <SectionHeader icon={<Bell className="size-4" aria-hidden="true" />}>
          {t(lang, "announcementType")}
        </SectionHeader>
        <RadioGroup
          value={settings.announcementMode}
          onValueChange={(v) => update("announcementMode", v as AnnouncementMode)}
          className="gap-2"
        >
          <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-border p-3 text-sm has-[:checked]:border-primary has-[:checked]:bg-accent">
            <RadioGroupItem value="remaining" />
            <span className="flex flex-col">
              <span className="font-medium">{t(lang, "remaining")}</span>
              <span className="text-xs text-muted-foreground">&ldquo;{t(lang, "remainingExample")}&rdquo;</span>
            </span>
          </label>
          <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-border p-3 text-sm has-[:checked]:border-primary has-[:checked]:bg-accent">
            <RadioGroupItem value="elapsed" />
            <span className="flex flex-col">
              <span className="font-medium">{t(lang, "elapsed")}</span>
              <span className="text-xs text-muted-foreground">&ldquo;{t(lang, "elapsedExample")}&rdquo;</span>
            </span>
          </label>
        </RadioGroup>
      </div>

      <div className="h-px bg-border" />

      {/* Frequency */}
      <div className="flex flex-col gap-3">
        <SectionHeader icon={<Bell className="size-4" aria-hidden="true" />}>
          {t(lang, "frequency")}
        </SectionHeader>
        <RadioGroup
          value={String(settings.announcementInterval)}
          onValueChange={(v) => update("announcementInterval", Number.parseInt(v, 10))}
          className="grid grid-cols-1 gap-2"
        >
          {INTERVALS.map((opt) => (
            <label
              key={opt.value}
              className="flex cursor-pointer items-center gap-3 rounded-lg border border-border px-3 py-2.5 text-sm has-[:checked]:border-primary has-[:checked]:bg-accent"
            >
              <RadioGroupItem value={String(opt.value)} />
              <span className="font-medium">{t(lang, opt.key)}</span>
            </label>
          ))}
        </RadioGroup>
      </div>

      <div className="h-px bg-border" />

      {/* Sound */}
      <div className="flex items-center justify-between gap-4">
        <Label htmlFor="sound-switch" className="flex items-center gap-2 text-sm font-medium">
          <Music className="size-4 text-primary" aria-hidden="true" />
          {t(lang, "enableSound")}
        </Label>
        <Switch
          id="sound-switch"
          checked={settings.soundEnabled}
          onCheckedChange={(v) => update("soundEnabled", v)}
        />
      </div>
    </div>
  )
}
