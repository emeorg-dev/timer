"use client"

import { cn } from "@/lib/utils"

function pad(n: number) {
  return n.toString().padStart(2, "0")
}

export function TimerDisplay({
  remaining,
  duration,
  status,
}: {
  remaining: number
  duration: number
  status: "idle" | "running" | "paused" | "finished"
}) {
  const hours = Math.floor(remaining / 3600)
  const minutes = Math.floor((remaining % 3600) / 60)
  const seconds = remaining % 60

  const progress = duration > 0 ? (duration - remaining) / duration : 0
  // Use a fixed SVG coordinate system and scale the rendered box responsively
  // so the circle always fits the viewport without causing scroll.
  const size = 280
  const stroke = 8
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const dashOffset = circumference * (1 - progress)

  return (
    <div
      className="relative aspect-square w-[min(78vw,46vh,360px)]"
      role="timer"
      aria-live="off"
      aria-label={`${pad(hours)}:${pad(minutes)}:${pad(seconds)}`}
    >
      <svg
        className="absolute inset-0 h-full w-full -rotate-90"
        viewBox={`0 0 ${size} ${size}`}
        aria-hidden="true"
      >
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--color-secondary)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={status === "finished" ? "var(--color-destructive)" : "var(--color-primary)"}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          className="transition-[stroke-dashoffset] duration-300 ease-linear"
        />
      </svg>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div
          className={cn(
            "font-mono tabular-nums tracking-tight",
            "text-[clamp(2.5rem,11vw,4rem)]",
            status === "finished" && "text-destructive",
          )}
        >
          {hours > 0 && <span>{pad(hours)}:</span>}
          <span>{pad(minutes)}:</span>
          <span>{pad(seconds)}</span>
        </div>
      </div>
    </div>
  )
}
