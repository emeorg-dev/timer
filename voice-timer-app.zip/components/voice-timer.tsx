"use client"

import { useCallback, useState } from "react"
import { Settings2 } from "lucide-react"
import { useSettings } from "@/components/settings-provider"
import { useTheme } from "@/hooks/use-theme"
import { useTimer } from "@/hooks/use-timer"
import { useSpeech } from "@/hooks/use-speech"
import { useSound } from "@/hooks/use-sound"
import { buildAnnouncement } from "@/lib/announcements"
import { t } from "@/lib/i18n"
import { TimerDisplay } from "@/components/timer-display"
import { TimerControls } from "@/components/timer-controls"
import { TimeSetup } from "@/components/time-setup"
import { SettingsPanel } from "@/components/settings-panel"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"

export function VoiceTimer() {
  const { settings, ready } = useSettings()
  useTheme(settings.theme)

  const { speak, cancel, unlock } = useSpeech()
  const { play } = useSound()

  // Time configuration (defaults to 15 minutes).
  const [hours, setHours] = useState(0)
  const [minutes, setMinutes] = useState(15)
  const [seconds, setSeconds] = useState(0)

  const durationSec = hours * 3600 + minutes * 60 + seconds

  const announce = useCallback(
    (elapsed: number, remaining: number) => {
      const { voiceEnabled, announcementInterval, announcementMode, language } = settings
      if (!voiceEnabled || announcementInterval <= 0) return

      const reference = announcementMode === "remaining" ? remaining : elapsed
      if (reference > 0 && reference % announcementInterval === 0) {
        if (announcementMode === "remaining" && remaining === 0) return
        speak(buildAnnouncement(reference, language, announcementMode), language)
      }
    },
    [settings, speak],
  )

  const handleFinish = useCallback(() => {
    if (settings.soundEnabled) play("finish")
    if (settings.voiceEnabled) {
      speak(buildAnnouncement(0, settings.language, settings.announcementMode), settings.language)
    }
  }, [settings, play, speak])

  const timer = useTimer(durationSec, { onSecond: announce, onFinish: handleFinish })

  const handleStart = useCallback(() => {
    if (settings.voiceEnabled) unlock()
    if (settings.soundEnabled) play("start")
    timer.start()
  }, [settings.soundEnabled, settings.voiceEnabled, unlock, play, timer])

  const handlePause = useCallback(() => {
    if (settings.soundEnabled) play("pause")
    cancel()
    timer.pause()
  }, [settings.soundEnabled, play, cancel, timer])

  const handleResume = useCallback(() => {
    timer.resume()
  }, [timer])

  const handleReset = useCallback(() => {
    cancel()
    timer.reset()
  }, [cancel, timer])

  const handleTimeChange = useCallback((h: number, m: number, s: number) => {
    setHours(h)
    setMinutes(m)
    setSeconds(s)
  }, [])

  const lang = settings.language
  const isIdle = timer.status === "idle"

  if (!ready) {
    return <div className="h-[100dvh] w-full bg-background" aria-hidden="true" />
  }

  return (
    <main className="relative flex h-[100dvh] w-full flex-col overflow-hidden bg-background">
      {/* Settings trigger (top-left) */}
      <Sheet>
        <SheetTrigger
          className="absolute left-4 top-4 z-10 flex size-10 items-center justify-center rounded-full border border-border bg-card text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
          aria-label={t(lang, "settings")}
        >
          <Settings2 className="size-5" aria-hidden="true" />
        </SheetTrigger>
        <SheetContent side="left" className="overflow-y-auto">
          <SheetTitle className="flex items-center gap-2">
            <Settings2 className="size-4 text-primary" aria-hidden="true" />
            {t(lang, "settings")}
          </SheetTitle>
          <div className="mt-2 flex flex-col gap-6">
            <SettingsPanel />
            <div className="flex items-center justify-between gap-4 border-t border-border pt-5">
              <span className="text-sm font-medium">{t(lang, "theme")}</span>
              <ThemeToggle />
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Centered timer fills available space */}
      <div className="flex min-h-0 flex-1 flex-col items-center justify-center gap-[clamp(1rem,4vh,2.5rem)] px-4 py-4">
        <TimerDisplay
          remaining={timer.remaining}
          duration={timer.duration || durationSec}
          status={timer.status}
        />

        <TimerControls
          status={timer.status}
          onStart={handleStart}
          onPause={handlePause}
          onResume={handleResume}
          onReset={handleReset}
        />

        {isIdle && (
          <div className="w-full max-w-md shrink-0">
            <TimeSetup
              hours={hours}
              minutes={minutes}
              seconds={seconds}
              onChange={handleTimeChange}
              disabled={!isIdle}
            />
          </div>
        )}
      </div>
    </main>
  )
}
