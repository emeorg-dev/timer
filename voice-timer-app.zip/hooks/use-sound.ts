"use client"

import { useCallback, useRef } from "react"

type SoundType = "start" | "pause" | "finish"

/**
 * Generates simple cue tones with the Web Audio API so no audio assets
 * need to be bundled. Each cue is a short sequence of sine beeps.
 */
export function useSound() {
  const ctxRef = useRef<AudioContext | null>(null)

  const getCtx = useCallback(() => {
    if (typeof window === "undefined") return null
    if (!ctxRef.current) {
      const AC = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
      if (!AC) return null
      ctxRef.current = new AC()
    }
    return ctxRef.current
  }, [])

  const tone = useCallback(
    (ctx: AudioContext, freq: number, start: number, duration: number) => {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = "sine"
      osc.frequency.value = freq
      osc.connect(gain)
      gain.connect(ctx.destination)
      const t0 = ctx.currentTime + start
      gain.gain.setValueAtTime(0.0001, t0)
      gain.gain.exponentialRampToValueAtTime(0.3, t0 + 0.02)
      gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration)
      osc.start(t0)
      osc.stop(t0 + duration)
    },
    [],
  )

  const play = useCallback(
    (type: SoundType) => {
      const ctx = getCtx()
      if (!ctx) return
      if (ctx.state === "suspended") void ctx.resume()

      switch (type) {
        case "start":
          tone(ctx, 660, 0, 0.15)
          tone(ctx, 880, 0.16, 0.18)
          break
        case "pause":
          tone(ctx, 440, 0, 0.18)
          break
        case "finish":
          tone(ctx, 880, 0, 0.2)
          tone(ctx, 660, 0.22, 0.2)
          tone(ctx, 990, 0.46, 0.35)
          break
      }
    },
    [getCtx, tone],
  )

  return { play }
}
