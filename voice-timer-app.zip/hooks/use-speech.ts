"use client"

import { useCallback, useEffect, useRef } from "react"
import type { LangCode } from "@/lib/i18n"

/** Wraps the Web Speech API (SpeechSynthesis) with voice selection per language. */
export function useSpeech() {
  const voicesRef = useRef<SpeechSynthesisVoice[]>([])
  const supportedRef = useRef(false)

  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return
    supportedRef.current = true

    const loadVoices = () => {
      voicesRef.current = window.speechSynthesis.getVoices()
    }
    loadVoices()
    window.speechSynthesis.onvoiceschanged = loadVoices

    return () => {
      window.speechSynthesis.onvoiceschanged = null
    }
  }, [])

  const unlockedRef = useRef(false)

  /**
   * Browsers block programmatic speech until it is triggered from a user
   * gesture. Call this inside a click handler (e.g. Start) to "unlock"
   * synthesis so later timer-driven announcements are allowed to play.
   */
  const unlock = useCallback(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return
    const synth = window.speechSynthesis
    // Refresh voices (Chrome populates them lazily after first interaction).
    voicesRef.current = synth.getVoices()
    if (unlockedRef.current) return
    // Speak a near-silent priming utterance within the gesture.
    const primer = new SpeechSynthesisUtterance(" ")
    primer.volume = 0
    synth.speak(primer)
    unlockedRef.current = true
  }, [])

  const pickVoice = useCallback((lang: LangCode): SpeechSynthesisVoice | undefined => {
    const voices = voicesRef.current
    if (!voices.length) return undefined
    // Exact locale match first, then language-prefix match.
    const prefix = lang.split("-")[0]
    return (
      voices.find((v) => v.lang === lang) ??
      voices.find((v) => v.lang.replace("_", "-") === lang) ??
      voices.find((v) => v.lang.toLowerCase().startsWith(prefix))
    )
  }, [])

  const speak = useCallback(
    (text: string, lang: LangCode) => {
      if (!supportedRef.current) return
      const synth = window.speechSynthesis
      // Cancel any queued speech so announcements don't pile up.
      synth.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = lang
      const voice = pickVoice(lang)
      if (voice) utterance.voice = voice
      utterance.rate = 1
      utterance.pitch = 1
      // Chrome occasionally pauses synthesis; nudging resume keeps it playing.
      synth.resume()
      synth.speak(utterance)
    },
    [pickVoice],
  )

  const cancel = useCallback(() => {
    if (supportedRef.current) window.speechSynthesis.cancel()
  }, [])

  return { speak, cancel, unlock }
}
