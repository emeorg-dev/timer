import type { LangCode } from "./i18n"

type AnnouncementMode = "remaining" | "elapsed"

interface PhraseUnits {
  hour: [string, string] // [singular, plural]
  minute: [string, string]
  second: [string, string]
  // builder receives the joined unit phrase (e.g. "10 minutes")
  remaining: (units: string) => string
  elapsed: (units: string) => string
  finished: string
  and: string
}

const PHRASES: Record<LangCode, PhraseUnits> = {
  "es-ES": {
    hour: ["hora", "horas"],
    minute: ["minuto", "minutos"],
    second: ["segundo", "segundos"],
    remaining: (u) => `Queda${u.startsWith("1 ") || u.startsWith("una ") ? "" : "n"} ${u}`,
    elapsed: (u) => `Ha${u.startsWith("1 ") || u.startsWith("una ") ? "" : "n"} pasado ${u}`,
    finished: "Tiempo finalizado",
    and: "y",
  },
  "en-US": {
    hour: ["hour", "hours"],
    minute: ["minute", "minutes"],
    second: ["second", "seconds"],
    remaining: (u) => `${u} remaining`,
    elapsed: (u) => `${u} ${u.startsWith("1 ") ? "has" : "have"} passed`,
    finished: "Time is up",
    and: "and",
  },
  "pt-BR": {
    hour: ["hora", "horas"],
    minute: ["minuto", "minutos"],
    second: ["segundo", "segundos"],
    remaining: (u) => `Falta${u.startsWith("1 ") || u.startsWith("uma ") ? "" : "m"} ${u}`,
    elapsed: (u) => `Passou${u.startsWith("1 ") || u.startsWith("uma ") ? "" : "ram"} ${u}`,
    finished: "Tempo esgotado",
    and: "e",
  },
  "fr-FR": {
    hour: ["heure", "heures"],
    minute: ["minute", "minutes"],
    second: ["seconde", "secondes"],
    remaining: (u) => `Il reste ${u}`,
    elapsed: (u) => `${u} ${u.startsWith("1 ") || u.startsWith("une ") ? "s'est écoulée" : "se sont écoulées"}`,
    finished: "Temps écoulé",
    and: "et",
  },
  "de-DE": {
    hour: ["Stunde", "Stunden"],
    minute: ["Minute", "Minuten"],
    second: ["Sekunde", "Sekunden"],
    remaining: (u) => `Noch ${u}`,
    elapsed: (u) => `${u} ${u.startsWith("1 ") || u.startsWith("eine ") ? "ist" : "sind"} vergangen`,
    finished: "Zeit abgelaufen",
    and: "und",
  },
  "it-IT": {
    hour: ["ora", "ore"],
    minute: ["minuto", "minuti"],
    second: ["secondo", "secondi"],
    remaining: (u) => `Manca${u.startsWith("1 ") || u.startsWith("un ") ? "" : "no"} ${u}`,
    elapsed: (u) => `${u.startsWith("1 ") || u.startsWith("un ") ? "È passato" : "Sono passati"} ${u}`,
    finished: "Tempo scaduto",
    and: "e",
  },
}

function unitPhrase(value: number, unit: [string, string]): string {
  return `${value} ${value === 1 ? unit[0] : unit[1]}`
}

/** Builds a localized spoken phrase from a total number of seconds. */
export function buildAnnouncement(totalSeconds: number, lang: LangCode, mode: AnnouncementMode): string {
  const p = PHRASES[lang]

  if (totalSeconds <= 0) {
    return p.finished
  }

  const hours = Math.floor(totalSeconds / 3600)
  const minutes = Math.floor((totalSeconds % 3600) / 60)
  const seconds = totalSeconds % 60

  const parts: string[] = []
  if (hours > 0) parts.push(unitPhrase(hours, p.hour))
  if (minutes > 0) parts.push(unitPhrase(minutes, p.minute))
  if (seconds > 0 && hours === 0) parts.push(unitPhrase(seconds, p.second))

  if (parts.length === 0) parts.push(unitPhrase(0, p.second))

  let units: string
  if (parts.length === 1) {
    units = parts[0]
  } else {
    units = `${parts.slice(0, -1).join(", ")} ${p.and} ${parts[parts.length - 1]}`
  }

  return mode === "remaining" ? p.remaining(units) : p.elapsed(units)
}
